
const levels = {
  1: 'Előkészület',
  2: 'Izgatás',
  3: 'Aktus'
};
let currentLevel = 3;
let players = [];

const tasks = {
  1: [
    {t:'Simogasd a párod combját lassan 1 percig.', img:'assets/images/heart.svg'},
    {t:'Csókoljátok végig egymás nyakát.', img:'assets/images/kiss.svg'}
  ],
  2: [
    {t:'Adj csókot a párod legérzékenyebb pontjára.', img:'assets/images/lips.svg'},
    {t:'Vetkőzz le egy ruhadarabot játékosan.', img:'assets/images/strip.svg'}
  ],
  3: [
    {t:'Kezdjétek el egymás izgatását orálisan.', img:'assets/images/devil-boy.svg'},
    {t:'Válasszatok egy pózt és próbáljátok ki.', img:'assets/images/position.svg'}
  ]
};

document.querySelectorAll('.level').forEach(b=>b.addEventListener('click', (e)=>{
  document.querySelectorAll('.level').forEach(x=>x.classList.remove('active'));
  e.currentTarget.classList.add('active');
  currentLevel = Number(e.currentTarget.dataset.level);
}));

document.getElementById('start').addEventListener('click', ()=>{
  const raw = document.getElementById('playersInput').value.trim();
  if(!raw){ alert('Add meg a játékosok neveit, pl. Anna, Péter'); return; }
  players = raw.split(',').map(s=>s.trim()).filter(Boolean);
  if(players.length<2){ alert('Legalább két játékos szükséges'); return; }
  document.getElementById('game').classList.remove('hidden');
});

function spinBottle(){
  const bottle = document.getElementById('bottle');
  const deg = Math.floor(Math.random()*360) + 720; // rotates rightward
  bottle.style.transform = `rotate(${deg}deg)`;
  // determine sector after spin
  setTimeout(()=>{
    const normalized = deg % 360;
    const sector = 360 / 4; // top,bottom,left,right
    let idx = Math.floor(normalized / sector);
    idx = (4 - idx) % 4; // invert to clockwise mapping
    const options = ['Ördöglány','Ördögfiú','Közösen','Pihenő'];
    const choice = options[idx];
    showTaskFor(choice);
  }, 3200);
}

function showTaskFor(choice){
  const res = document.getElementById('result');
  const txt = document.getElementById('taskText');
  const ill = document.getElementById('illustration');
  res.classList.remove('hidden');
  // choose a random task from current level
  const list = tasks[currentLevel] || [];
  const task = list[Math.floor(Math.random()*list.length)];
  txt.textContent = choice + ': ' + task.t;
  ill.src = task.img;
}

document.getElementById('spin').addEventListener('click', spinBottle);
document.getElementById('tod').addEventListener('click', ()=>{
  // show a random TOD from current level
  const list = tasks[currentLevel] || [];
  const task = list[Math.floor(Math.random()*list.length)];
  document.getElementById('result').classList.remove('hidden');
  document.getElementById('taskText').textContent = task.t;
  document.getElementById('illustration').src = task.img;
});
